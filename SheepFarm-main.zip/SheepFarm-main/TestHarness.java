
public class TestHarness {

	public static void GenerateSheep() {
		// public Sheep(String sName, String sFavColor, int sheight, int sweight)
//		Sheep s = new Sheep("Bill", "Orange", 62,34);
//		System.out.println("**** ----  Adding a sheep:");
//		(ListOfSheep.SheepRoster).add(s);	
		

		// Declaring an array of sheep
        Sheep[] updatedSheepArray;
        
        // Allocating memory for 10 objects
        // of type student
        updatedSheepArray = new Sheep[10];
 
        // Initializing 10 elements of array 
        updatedSheepArray[0] = new Sheep("Bill", "Orange", 62,34);
        updatedSheepArray[1] = new Sheep("will", "Orange", 62,34);
        updatedSheepArray[2] = new Sheep("dill", "Orange", 62,34);
        updatedSheepArray[3] = new Sheep("zill", "Orange", 62,34);
        updatedSheepArray[4] = new Sheep("kill", "Orange", 62,34);
        updatedSheepArray[5] = new Sheep("sill", "Orange", 62,34);
        updatedSheepArray[6] = new Sheep("till", "Orange", 62,34);
        updatedSheepArray[7] = new Sheep("rill", "Orange", 62,34);
        updatedSheepArray[8] = new Sheep("jill", "Orange", 62,34);
        updatedSheepArray[9] = new Sheep("pill", "Orange", 62,34);
        

        for (int i = 0; i < updatedSheepArray.length; i++) {
        	
        	(ListOfSheep.SheepRoster).add(updatedSheepArray[i]);
    	}
		
	}
	
}
